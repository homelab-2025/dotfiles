# Dotfiles

Small repo to store dotfiles